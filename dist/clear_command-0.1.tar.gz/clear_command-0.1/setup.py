from setuptools import setup, find_packages

setup(
    name="clear-command",
    version='0.1',
    author="Malik Hassan",
    author_email="<malikkhabhassan@gmail.com>",
    packages=find_packages(),
    install_requires=[],
    keywords=['python', 'command', 'clear', 'clear command', 'console clear', 'console'],
)